package b;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class AdminActionServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        String idStr = req.getParameter("id");
        Connection conn = null;

        try {
            int id = Integer.parseInt(idStr);
            conn = DBConnection.getConnection();

            if ("deleteUser".equals(action)) {
                PreparedStatement ps = conn.prepareStatement("DELETE FROM users WHERE id = ?");
                ps.setInt(1, id);
                ps.executeUpdate();
            } else if ("deleteDonation".equals(action)) {
                PreparedStatement ps = conn.prepareStatement("DELETE FROM donations WHERE id = ?");
                ps.setInt(1, id);
                ps.executeUpdate();
            } else if ("updateStatus".equals(action)) {
                String status = req.getParameter("status");
                PreparedStatement ps = conn.prepareStatement("UPDATE donations SET status = ? WHERE id = ?");
                ps.setString(1, status);
                ps.setInt(2, id);
                ps.executeUpdate();
            }

            res.sendRedirect("admin_dashboard.jsp");

        } catch (Exception e) {
            e.printStackTrace(res.getWriter());
        }
    }
}
