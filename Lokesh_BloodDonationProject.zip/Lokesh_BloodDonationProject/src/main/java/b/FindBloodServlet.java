package b;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class FindBloodServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String bloodgroup = req.getParameter("bloodgroup");
        String city = req.getParameter("city");

        res.setContentType("text/html;charset=UTF-8");

        try {
            Connection conn = DBConnection.getConnection();
            if (conn == null) {
                throw new Exception("Database connection failed.");
            }

            String sql = "SELECT name, bloodgroup, city, contact, email FROM donations WHERE bloodgroup=? AND city LIKE ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, bloodgroup);
            ps.setString(2, city.trim() + "%");

            ResultSet rs = ps.executeQuery();

            // Start HTML
            res.getWriter().println("<!DOCTYPE html>");
            res.getWriter().println("<html lang='en'>");
            res.getWriter().println("<head>");
            res.getWriter().println("<meta charset='UTF-8'>");
            res.getWriter().println("<title>Available Donors</title>");
            res.getWriter().println("<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>");

            // CSS styles
            res.getWriter().println("<style>");
            res.getWriter().println("body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background: linear-gradient(135deg, #ff4e50, #f9d423); color: white; animation: fadeIn 1.5s ease-in; }");
            res.getWriter().println("@keyframes fadeIn { from {opacity: 0;} to {opacity: 1;} }");

            // Header
            res.getWriter().println("header { text-align: center; padding: 30px 15px; background-color: rgba(0, 0, 0, 0.3); box-shadow: 0 4px 10px rgba(0,0,0,0.3); }");
            res.getWriter().println("header h1 { font-size: 2.5em; margin-bottom: 10px; text-shadow: 2px 2px 8px rgba(0,0,0,0.5); }");

            // Nav
            res.getWriter().println("nav { display: flex; justify-content: center; gap: 20px; flex-wrap: wrap; margin-top: 15px; }");
            res.getWriter().println("nav a { text-decoration: none; color: white; padding: 10px 20px; border-radius: 30px; background: rgba(0,0,0,0.2); transition: 0.3s ease; font-weight: bold; }");
            res.getWriter().println("nav a:hover { background: white; color: #ff4e50; transform: scale(1.1); }");

            // Table
            res.getWriter().println("h2 { text-align: center; margin-top: 40px; }");
            res.getWriter().println("table { width: 100%; max-width: 1000px; margin: 30px auto; border-collapse: collapse; background: rgba(255,255,255,0.15); border-radius: 12px; overflow: hidden; box-shadow: 0 0 10px rgba(0,0,0,0.4); }");
            res.getWriter().println("th, td { padding: 12px 15px; text-align: left; }");
            res.getWriter().println("th { background-color: #e91e63; color: white; }");
            res.getWriter().println("tr:nth-child(even) { background-color: rgba(255, 255, 255, 0.1); }");
            res.getWriter().println("tr:nth-child(odd) { background-color: rgba(255, 255, 255, 0.2); }");
            res.getWriter().println("td { color: white; }");

            // Buttons
            res.getWriter().println(".center { text-align: center; margin-top: 30px; }");
            res.getWriter().println(".btn { padding: 10px 25px; background: white; color: #ff4e50; font-weight: bold; border: none; border-radius: 30px; cursor: pointer; text-decoration: none; transition: 0.3s; }");
            res.getWriter().println(".btn:hover { background: #ff4e50; color: white; }");
            res.getWriter().println("</style>");

            res.getWriter().println("</head>");
            res.getWriter().println("<body>");

            // Header + Nav
            res.getWriter().println("<header>");
            res.getWriter().println("<h1>Welcome to Blood Donation Portal</h1>");
            res.getWriter().println("<nav>");
            res.getWriter().println("<a href='index.jsp'>Home</a>");
            res.getWriter().println("<a href='about.jsp'>About</a>");
            res.getWriter().println("<a href='bloodfind.jsp'>Find Blood</a>");
            res.getWriter().println("<a href='login.jsp'>Sign In</a>");
            res.getWriter().println("<a href='donate.jsp'>Donate Blood</a>");
            res.getWriter().println("<a href='news.jsp'>News</a>");
            res.getWriter().println("</nav>");
            res.getWriter().println("</header>");

            // Title
            res.getWriter().println("<h2>Blood Donors for " + bloodgroup + " in " + city + "</h2>");

            boolean found = false;

            // Table
            res.getWriter().println("<table>");
            res.getWriter().println("<tr><th>Name</th><th>Blood Group</th><th>City</th><th>Contact</th><th>Email</th></tr>");

            while (rs.next()) {
                found = true;
                String name = rs.getString("name");
                String bg = rs.getString("bloodgroup");
                String donorCity = rs.getString("city");
                String contact = rs.getString("contact");
                String email = rs.getString("email");

                res.getWriter().println("<tr>");
                res.getWriter().println("<td>" + name + "</td>");
                res.getWriter().println("<td>" + bg + "</td>");
                res.getWriter().println("<td>" + donorCity + "</td>");
                res.getWriter().println("<td>" + contact + "</td>");
                res.getWriter().println("<td>" + email + "</td>");
                res.getWriter().println("</tr>");
            }
            res.getWriter().println("</table>");

            if (!found) {
                res.getWriter().println("<p class='center' style='color: yellow;'>No donors found for your selection.</p>");
            }

            // Buttons
            res.getWriter().println("<div class='center'>");
            res.getWriter().println("<a href='bloodfind.jsp' class='btn'>🔙 Search Again</a>");
            res.getWriter().println("</div>");

            res.getWriter().println("<div class='center'>");
            res.getWriter().println("<button onclick='window.print()' class='btn'>🖨️ Print / Save as PDF</button>");
            res.getWriter().println("</div>");

            res.getWriter().println("</body></html>");

            rs.close();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace(res.getWriter());
            res.getWriter().println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
