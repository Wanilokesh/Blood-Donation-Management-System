package b;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.sql.*;

public class DonateServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String name = req.getParameter("name");
        String ageStr = req.getParameter("age");
        String gender = req.getParameter("gender");
        String bloodgroup = req.getParameter("bloodgroup");
        String email = req.getParameter("email");
        String contact = req.getParameter("contact");
        String city = req.getParameter("city");
        String address = req.getParameter("address");

        res.setContentType("text/html;charset=UTF-8");

        try {
            int age = Integer.parseInt(ageStr);

            Connection conn = DBConnection.getConnection(); // Your DB connection method
            if (conn == null) {
                throw new Exception("Failed to establish database connection.");
            }

            String sql = "INSERT INTO donations (name, age, gender, bloodgroup, email, contact, city, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setInt(2, age);
            ps.setString(3, gender);
            ps.setString(4, bloodgroup);
            ps.setString(5, email);
            ps.setString(6, contact);
            ps.setString(7, city);
            ps.setString(8, address);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                // Pass donor name and city to JSP as attributes
                req.setAttribute("name", name);
                req.setAttribute("city", city);

                // Forward to thankyou.jsp
                req.getRequestDispatcher("thankyou.jsp").forward(req, res);
            } else {
                res.getWriter().println("<h3>Failed to record your donation. Please try again.</h3>");
            }

            ps.close();
            conn.close();

        } catch (NumberFormatException e) {
            res.getWriter().println("<h3>Invalid age entered.</h3>");
        } catch (Exception e) {
            e.printStackTrace(res.getWriter());
            res.getWriter().println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
