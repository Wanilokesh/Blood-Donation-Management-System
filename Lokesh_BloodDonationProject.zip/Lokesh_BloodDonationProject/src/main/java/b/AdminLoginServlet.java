package b;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AdminLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");

        if ("admin".equals(username) && "12345".equals(password)) {
            HttpSession session = req.getSession();
            session.setAttribute("admin", "true");
            res.sendRedirect("admin_dashboard.jsp");
        } else {
            req.setAttribute("error", "Invalid admin credentials.");
            RequestDispatcher rd = req.getRequestDispatcher("admin_login.jsp");
            rd.forward(req, res);
        }
    }
}
