package b;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    private static Connection connection = null;

    public static Connection getConnection() throws Exception {
        if (connection == null || connection.isClosed()) {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // MySQL connection URL
            String dbURL = "jdbc:mysql://localhost:3306/blood_donation_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
            String username = "root";          // Your MySQL username
            String password = "Lokesh@123";    // Your MySQL password

            connection = DriverManager.getConnection(dbURL, username, password);
        }
        return connection;
    }
}
