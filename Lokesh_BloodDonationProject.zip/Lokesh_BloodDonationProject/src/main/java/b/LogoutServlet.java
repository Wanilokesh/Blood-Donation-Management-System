package b;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LogoutServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false); // Get session if exists
        if (session != null) {
            session.invalidate(); // Invalidate the session
        }

        // Redirect to index.jsp after logout (for both admin and user)
        res.sendRedirect("index.jsp");
    }
}
