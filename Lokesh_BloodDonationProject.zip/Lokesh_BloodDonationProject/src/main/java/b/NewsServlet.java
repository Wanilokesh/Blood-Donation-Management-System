package b;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class NewsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            Connection conn = DBConnection.getConnection();
            if (conn == null) throw new Exception("DB Connection failed");

            // Use exact column names matching your table schema (uppercase)
            String sql = "SELECT CITY, BLOODGROUP, COUNT(*) AS count FROM donations GROUP BY CITY, BLOODGROUP";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            // Map<City, Map<BloodGroup, Count>>
            Map<String, Map<String, Integer>> data = new HashMap<>();

            while (rs.next()) {
                String city = rs.getString("CITY");
                String bg = rs.getString("BLOODGROUP");
                int count = rs.getInt("count");

                Map<String, Integer> bgMap = data.get(city);
                if (bgMap == null) {
                    bgMap = new HashMap<>();
                    data.put(city, bgMap);
                }
                bgMap.put(bg, count);
            }

            rs.close();
            stmt.close();
            conn.close();

            // Pass the data map to the JSP
            req.setAttribute("data", data);
            req.getRequestDispatcher("news.jsp").forward(req, resp);

        } catch (Exception e) {
            e.printStackTrace(resp.getWriter());
            resp.getWriter().println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
