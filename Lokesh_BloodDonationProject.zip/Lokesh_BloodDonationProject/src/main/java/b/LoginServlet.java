package b;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*; 

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");

        // 1. Admin check — hardcoded
        if ("admin".equalsIgnoreCase(username) && "12345".equals(password)) {
            HttpSession session = req.getSession();
            session.setAttribute("username", "admin");
            session.setAttribute("role", "admin");
            res.sendRedirect("admin_dashboard.jsp");
            return;
        }

        // 2. User login — DB check
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT * FROM users WHERE username = ? AND password = ?")) {

            ps.setString(1, username); 
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Valid user
                    HttpSession session = req.getSession();
                    session.setAttribute("username", username);
                    session.setAttribute("role", "user");
                    res.sendRedirect("welcome.jsp"); // or user_dashboard.jsp
                } else {
                    // Invalid credentials
                    req.setAttribute("error", "Invalid username or password.");
                    req.getRequestDispatcher("login.jsp").forward(req, res);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Server error. Please try again later.");
            req.getRequestDispatcher("login.jsp").forward(req, res);
        }
    } 
}
